insert into Person (id, email, first_name, last_name, password) values (1, 'jim@arnellconsulting.com', 'Jim', 'Arnell', 'password');
insert into Person (id, email, first_name, last_name, password) values (2, 'erwin@test.org', 'Erwin', 'Svensson', 'password');
insert into Person (id, email, first_name, last_name, password) values (3, 'jeremy@test.org', 'Jeremy', 'Svensson', 'password');
insert into Person (id, email, first_name, last_name, password) values (4, 'scott@test.org', 'Scott', 'Svensson', 'password');

insert into Project (id, name) value (1, 'Project A');
insert into Project (id, name) value (2, 'Project B');
insert into Project (id, name) value (3, 'Project C');	